﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace bmi_and_karvonen_calculator
{
	class Program
	{
		static void Main(string[] args)
		{
			const double LbsToKg = 2.205;
			const double InchToCenti = 2.54;

			Console.WriteLine("Andres's BMI & Karvonen Calculator");
			Console.WriteLine("									");
			Console.WriteLine("Please enter the following values for the user . . .");
			Console.WriteLine("									");

			Console.Write("Height in inches: ");
			string input = Console.ReadLine();
			int Height = Int32.Parse(input);

			Console.Write("Weight in pounds: ");
			input = Console.ReadLine();
			int Weight = Int32.Parse(input);

			Console.Write("Age: ");
			input = Console.ReadLine();
			int Age = Int32.Parse(input);

			Console.Write("Resting heart rate: ");
			input = Console.ReadLine();
			int HeartRate = Int32.Parse(input);

			Console.WriteLine("									");

			Console.WriteLine("Results . . .");

			double KiloGram = Weight / LbsToKg;
			double Centi = Height * InchToCenti;
			double Meter = Centi / 100;
			double Bmi = KiloGram / (Meter * Meter);
			string BmiExtra;

			if (Bmi <= 18.5)
			{
				BmiExtra = "You're Underweight.";

			}
			else if (18.6 <= Bmi && Bmi <= 24.9)
			{
				BmiExtra = "You're Normal weight.";
			}

			else if (25.0 <= Bmi && Bmi <= 29.9)
			{
				BmiExtra = " You're Overweight. ";
			}
			else
			{
				BmiExtra = "You're Obese.";

			}

			Console.WriteLine("your BMI is " + Math.Round(Bmi, 2) + "  " + BmiExtra);
			Console.WriteLine("            ");
			Console.WriteLine("Please hit enter to reach Heart Rate Section");
			Console.ReadLine();


			// the next program


			Console.WriteLine("            ");
			Console.WriteLine("Exercise Intenstiy of Workouts");
			Console.WriteLine("Intensity         Max Heart Rate");
			int MaxHeartRate = 220 - Age;
			int RestHeartRate = MaxHeartRate - HeartRate;
			double Intensity = .5;

			
			while (Intensity <= 1.0)
			{
			double WorkoutHeartRate = (RestHeartRate * Intensity) + HeartRate;


				Console.WriteLine(Intensity.ToString("P0") + "       --        " + Math.Round(WorkoutHeartRate, 0));
				Intensity += 0.05;
			}
			Console.ReadLine();



		}
	}
}
